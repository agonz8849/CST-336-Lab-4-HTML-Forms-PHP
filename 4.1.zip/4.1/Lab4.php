<!DOCTYPE html>
<html>
    <head>
        <title> Register to Support Candidate</title>
        <link rel="stylesheet" type="text/css" href="css/Lab4.css"> </link>
    </head>
    <body>

<div class = "contain">
<h1 class = "support"> Support your Presidential Candidate</h1>
<img class = "Candidates" src= "Images/2016_Pres.png"> </img>
<br>
<form action= "return_data.php" method ="post"> 
 <label class = "nombre">Enter your name:</label>   
 <input class = "user_name" name =" name" type = "text" value= "">
 
 <br>
 <br>
 <label class = "eumar">Enter your age:</label>   <!--eumar is age in Arabic-->
 <input class = "user_age" name =" age" type = "text" value= "">
  <p style= "display:inline", >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Must be at least 18 or older) </p>
 <br>
 <br>
 
<label class = "choose_can"> Select your Candidate</label>
<select class = "choose" name ="candidate" size =1;> 
<option>  </option>
<option>Jill Stein</option>
<option>Hillary Clinton</option>
<option>Gary Johnson</option>
<option>Darrell Castle</option>
<option>Evan McMullin</option>
<option>Donald Trump</option>
</select>

<br>
<br>
 <label class = "merchandise"><b>Merchandise</b></label><br>
 <div class = "check"> 


 <input  type="checkbox" id="1" name="merchandise[]" value= "5"> <label class = "num" for="1">Pin ($5)</label><br> 
 <input  type="checkbox" id = "2" name="merchandise[]" value = "10"><label class = "num" for="2">Tote Bag ($10).</label> <br>  
 <input   type="checkbox" id="3" name ="merchandise[]" value = "15"> <label class = "num" for="3">Mug ($15).</label>  <br>
 <input   type="checkbox" id="Cap" name = "merchandise[]" value = "20"> <label class="num" for="4">Cap ($20).</label>  <br><br>
</div>

<label class = "camp_mag"> <b>Campaign Magazine ($10 per month)</b></label> <br>
<div class = "choose_month">
&nbsp;&nbsp;&nbsp;<input type= "radio" id="1" name = "month" value= "1 "> <label class= "item" for = "1">1 month</label> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type= "radio" id="3" name = "month" value= "3 "> <label class= "item" for = "3">3 months</label> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type= "radio" id="6" name = "month" value= "6  "> <label class= "item" for = "6">6 months</label> 
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type= "radio" id="12" name = "month" value= "12  "> <label class= "item" for = "12">12 months</label>
</div>   
   <br>
   <div class = "button_submit">
   <input type = "submit" name= "butt_submit"  value= "Buy Now" > 
    </div>
</form>


</div>
    </body>
</html>