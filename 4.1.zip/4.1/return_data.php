<!DOCTYPE html>
<html>
    <head>
    <title> Lab 4: HTMl Forms & PHP</title>
    <link rel="stylesheet" type="text/css" href="css/Lab4.css"> </link>
    </head>
    <body>
<div class = "contain">
<br>
<br>
<br>
<br>
<br>

<?php
if ( empty($_POST["name"]) ) 
{
echo "<div class = 'error_on_name'>";
echo "You didn't put in your name!!!!";	
echo "<br>";
echo "</div>";
}
else 
{
      echo "<p class = 'Dear'> Dear "  . "<b>".$_POST["name"]. "</b>".", ";
}

echo"<br>";
echo"<br>";



if (empty($_POST["candidate"]))
{
    echo "<div class = 'error_on_name'>";
    echo "You need to choose a candidate!!!!";
    echo "<br>";
    echo "</div>";
}
else 
{
    echo"Thank you for supporting";
    echo" ";
   echo""."<b>". $_POST["candidate"]. "</b>";
   echo "</p>";
}
        





 
if ( empty($_POST["age"]))
{
   echo" <div class ='error_age'>";
    echo "You didn't put in your age";
    echo"<br>";
  echo "</div>";
}
  

else if (!is_numeric($_POST["age"]))
{
     echo "<div class ='error_age'>";
    echo "Age should be a number!!!!";
    echo"<br>";
    echo "</div>";
}
else if ($_POST["age"] < 18)
{
    echo "<div class ='error_age'>";
    echo "You're too young to support a candidate!!!!";
    echo "<br>";
    echo "</div>";
}
else if($_POST["age"] > 122) 
{ echo "<div class ='error_age'>";
    echo "You're way too old to be voting just drop dead!!!";
    echo"<br>";
     echo "</div>";
}

echo"<br>";
echo"<br>";


echo"<div class ='stuff'>";
echo"You ordered these products: ";
echo"<br>";
echo"<br>";
echo "</div>";




$sum =0;
if (isset($_POST["butt_submit"]))
{

    if (!empty($_POST["merchandise"]))
    {
    
        foreach($_POST["merchandise"] as $selected)
        {
            echo"<div class = 'marked'>";
            
            
            
            if ($selected == "5")
            {
            echo "Pin ($".$selected.")";
            echo "<br>";
            }       
             if ($selected == "10")
                 {
                      echo "Tote Bag ($".$selected.")";
                       echo "<br>";
                 }     
               if ($selected == "15")
                 {
                      echo "Mug ($".$selected.")";
                       echo "<br>";
                 }         
                 
                   if ($selected == "20")
                 {
                      echo "Cap ($".$selected.")";
                       echo "<br>";
                 }  
                  $sum +=  $selected;
                 
            echo "</div>";
   
        }
     }
       else
       {
           echo "<div class = 'no_mark'>";
           echo "You didn't check anything!!!!!!!!!";
           echo "<br>";
           echo "</div>";
       }
}


if (isset($_POST["butt_submit"]))
{
    if (!empty($_POST["month"]) )
    {
       $magprice = $_POST["month"] *10;
       echo "<div class= 'months'>";
       echo$_POST["month"]."-months"." Campaign Magazine Subscription". " ($".$magprice.")";
        echo "<br>";
        echo "<br>";
        echo "</div>";
    }

    else
    { 
        echo "<div class= 'months'>";
        echo "You didn't choose a month";
        echo "<br>";
        echo "<br>";
        echo "</div>";
    }
}
    

echo "<div class ='ttl'>"; 

$total_amount = $sum +$magprice; 

if ( empty($_POST["name"]) ) 
{
$total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: Invalid name";

}
else if ( empty($_POST["age"]))
{
   $total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: Invalid age!!!";
   
}
else if (!is_numeric($_POST["age"]))
{
     $total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: Invalid age!!!";
}
else if ($_POST["age"] < 18)
{
     $total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: Invalid age!!!";
}
else if($_POST["age"] > 122) 
{ 
     $total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: Invalid age!!!";
}
else if (empty($_POST["candidate"]))
{
     $total_amount = 0;
   echo "Total: ". "$".$total_amount;
       echo "<br>";
   echo "Reason: No candidate was chosen!!!";
}

else
{
   echo "Total: ". "$".$total_amount; 
}

echo"</div>";
echo "<br>";
        echo "<br>";
        echo "<br>";
          echo "<br>";
        echo "<br>";
?>




</div>
</body> 

</html>
